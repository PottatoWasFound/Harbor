// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "Harbor",
    platforms: [.macOS(.v13)],
    products: [.executable(name: "Harbor", targets: ["Harbor"]), .executable(name: "harbor-worker", targets: ["HarborWorker"])],
    targets: [
        .target(name: "HarborCore"),
        .executableTarget(name: "Harbor", dependencies: ["HarborCore"]),
        .executableTarget(name: "HarborWorker"),
        .executableTarget(name: "HarborChecks", dependencies: ["HarborCore"], path: "Tests/HarborCoreTests")
    ]
)
