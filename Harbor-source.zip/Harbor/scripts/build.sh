#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
export CLANG_MODULE_CACHE_PATH="$PWD/.build/ModuleCache"
export SWIFTPM_MODULECACHE_OVERRIDE="$CLANG_MODULE_CACHE_PATH"
swift build -c release --disable-sandbox --cache-path .build/cache --config-path .build/config --security-path .build/security
HARBOR_BIN="$(swift build -c release --show-bin-path --disable-sandbox --cache-path .build/cache --config-path .build/config --security-path .build/security)"
HARBOR_APP="${1:-../Harbor.app}"
mkdir -p "$HARBOR_APP/Contents/MacOS" "$HARBOR_APP/Contents/Resources"
cp "$HARBOR_BIN/Harbor" "$HARBOR_APP/Contents/MacOS/Harbor"
cp "$HARBOR_BIN/harbor-worker" "$HARBOR_APP/Contents/MacOS/harbor-worker"
cat > "$HARBOR_APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>Harbor</string>
<key>CFBundleIdentifier</key><string>dev.harbor.local</string>
<key>CFBundleName</key><string>Harbor</string>
<key>CFBundleDisplayName</key><string>Harbor</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>0.1.0</string>
<key>CFBundleVersion</key><string>2</string>
<key>NSHumanReadableCopyright</key><string>Created by darils</string>
<key>LSMinimumSystemVersion</key><string>13.0</string>
<key>NSHighResolutionCapable</key><true/>
<key>NSPrincipalClass</key><string>NSApplication</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
</dict></plist>
PLIST
swift scripts/icon.swift "$HARBOR_APP/Contents/Resources"
codesign --force --sign - "$HARBOR_APP/Contents/MacOS/harbor-worker"
codesign --force --sign - "$HARBOR_APP"
echo "Built $HARBOR_APP"
