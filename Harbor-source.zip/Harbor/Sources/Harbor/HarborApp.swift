import SwiftUI
import AppKit

@main struct HarborApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject private var model = AppModel()
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(model)
                .frame(minWidth: 1040, minHeight: 720)
                .preferredColorScheme(.dark)
                .onAppear { delegate.model = model; NSApp.setActivationPolicy(.regular); NSApp.activate(ignoringOtherApps: true) }
        }
        .windowStyle(.hiddenTitleBar)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("New Laravel Project") { model.showCreate = true }.keyboardShortcut("n")
                Button("Import Project…") { model.importProject() }.keyboardShortcut("o")
            }
            CommandMenu("Development") {
                Button("Start All Web Servers") { model.startWebProjects() }
                Button("Stop All Project Processes") { model.stopAll() }
                Button("Refresh Services") { Task { await model.refresh() } }.keyboardShortcut("r")
            }
        }
        MenuBarExtra("Harbor", systemImage: "ferry.fill") {
            Text("\(model.activeCount) processes running")
            Button("Open Harbor") { NSApp.activate(ignoringOtherApps: true); NSApp.windows.first?.makeKeyAndOrderFront(nil) }
            Divider()
            Button("Start All Web Servers") { model.startWebProjects() }
            Button("Stop All Project Processes") { model.stopAll() }
            Divider()
            Button("Quit Harbor") { NSApp.terminate(nil) }
        }
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    var model: AppModel?
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        guard let model, model.activeCount > 0 else { return .terminateNow }
        model.stopAll(includeTools: true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.3) { sender.reply(toApplicationShouldTerminate: true) }
        return .terminateLater
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { false }
}
