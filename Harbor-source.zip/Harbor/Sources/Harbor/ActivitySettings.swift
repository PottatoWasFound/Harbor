import SwiftUI
import AppKit

struct ActivityPage: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        HStack {
            PageHeading(eyebrow: "Under the hood", title: "Activity & logs", subtitle: "Live output from your projects, installations, and service commands.")
            Spacer(); ActionButton(title: "Log folder", icon: "folder") { model.reveal(model.support.appendingPathComponent("Logs").path) }
        }
        if model.jobs.isEmpty { Card { VStack(alignment: .leading, spacing: 10) { Text("A quiet harbor.").font(.system(size: 17, weight: .medium)); Text("Start a project or install a tool to see its output here. Previous session logs are available in the log folder.").font(.system(size: 12)).foregroundColor(Palette.muted) } } }
        ForEach(model.jobs) { JobCard(job: $0) }
    }
}
struct JobCard: View {
    @ObservedObject var job: Job
    @State private var expanded = false
    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 13) {
                HStack(spacing: 12) {
                    Image(systemName: job.running ? "waveform" : job.exitCode == 0 ? "checkmark.circle" : "exclamationmark.circle").foregroundColor(job.running || job.exitCode == 0 ? Palette.accent : .orange)
                    VStack(alignment: .leading, spacing: 4) { Text(job.title).font(.system(size: 12, weight: .semibold)); Text(job.started.formatted(date: .omitted, time: .standard)).font(.system(size: 9)).foregroundColor(Palette.muted) }
                    Spacer()
                    Badge(text: job.stopping ? "Stopping" : job.running ? "Running" : "Exit \(job.exitCode ?? -1)", active: job.running)
                    if job.running { Button("Stop") { job.stop() }.font(.system(size: 11)) }
                    Button { expanded.toggle() } label: { Image(systemName: expanded ? "chevron.up" : "chevron.down") }.buttonStyle(.plain)
                }
                if expanded {
                    ScrollView([.vertical, .horizontal]) { Text(job.output.isEmpty ? "Waiting for output…" : job.output).font(.system(size: 11, design: .monospaced)).foregroundColor(.white.opacity(0.8)).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .topLeading).padding(14) }.frame(height: 230).background(Palette.background).cornerRadius(6)
                    HStack { Button("Copy visible log") { NSPasteboard.general.clearContents(); NSPasteboard.general.setString(job.output, forType: .string) }; Button("Show log file") { NSWorkspace.shared.activateFileViewerSelecting([job.logURL]) }; Spacer(); Text("Logs may contain application data.").foregroundColor(Palette.muted) }.font(.system(size: 10))
                }
            }
        }.onAppear { expanded = job.running || job.exitCode != 0 }
    }
}

struct SettingsPage: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        PageHeading(eyebrow: "Make yourself at home", title: "Settings & domains", subtitle: "A native workspace that works with the tools on your Mac.")
        Card {
            VStack(alignment: .leading, spacing: 16) {
                Label("Pretty URLs & HTTPS", systemImage: "lock.shield").font(.system(size: 17, weight: .semibold))
                Text("Harbor serves projects at 127.0.0.1 on dedicated ports. For Laragon-style project.test addresses and trusted local HTTPS, set up Laravel Valet, then use Link and Secure in each project's menu.").font(.system(size: 12)).foregroundColor(Palette.muted)
                Text("Valet setup runs in Terminal and may ask for your Mac password. It installs and configures Nginx and local DNS, and can change an existing web server setup. Valet's web server and PHP selection are managed separately from Harbor's development server.").font(.system(size: 11)).foregroundColor(Palette.muted)
                HStack { ActionButton(title: "Set up Valet in Terminal", icon: "terminal", primary: true) { model.valet(nil, action: "install") }.disabled(model.executable("composer") == nil); ActionButton(title: "Valet documentation", icon: "arrow.up.right") { model.openURL("https://laravel.com/docs/valet") } }
            }
        }
        Card {
            VStack(alignment: .leading, spacing: 15) {
                Label("Laravel extras", systemImage: "shippingbox").font(.system(size: 17, weight: .semibold))
                Text("Install the Laravel CLI for interactive starter-kit selection. Project terminals support Sail, Pint, Pest, migrations, authentication scaffolding, and any other Composer or Artisan workflow your project provides.").font(.system(size: 12)).foregroundColor(Palette.muted)
                HStack { ActionButton(title: "Install Laravel CLI in Terminal", icon: "terminal") { model.terminal(command: "composer global require laravel/installer") }.disabled(model.executable("composer") == nil); ActionButton(title: "Laravel documentation", icon: "book") { model.openURL("https://laravel.com/docs") } }
                Text("Horizon, Reverb, and starter kits are optional project packages. Sail requires Docker. These are not bundled with Harbor.").font(.system(size: 11)).foregroundColor(Palette.muted)
            }
        }
        Card {
            VStack(alignment: .leading, spacing: 15) {
                Label("Workspace & lifecycle", systemImage: "externaldrive").font(.system(size: 17, weight: .semibold))
                info("Homebrew", model.brew ?? "Not installed")
                info("Project registry & logs", model.support.path)
                info("Window closed", "Harbor stays in the menu bar; projects keep running.")
                info("App quit", "Harbor stops its project processes and their child processes.")
                info("Homebrew services", "Shared services keep running until explicitly stopped.")
                info("Network", "Harbor's web, Vite, and Reverb processes bind to loopback. Homebrew services use their own configuration.")
                HStack { ActionButton(title: "Open data folder", icon: "folder") { model.reveal(model.support.path) }; ActionButton(title: "Refresh tools", icon: "arrow.clockwise") { Task { await model.refresh() } } }
            }
        }
        VStack(alignment: .leading, spacing: 8) {
            Text("Harbor · Created by darils").font(.system(size: 13, weight: .semibold)).foregroundColor(Palette.accent)
            Text("Version 0.1 · An independent macOS app inspired by Laragon. Not affiliated with Laravel or Laragon. No analytics. Runtime downloads are managed by Homebrew and Composer.").font(.system(size: 10)).foregroundColor(Palette.muted)
        }
    }
    func info(_ name: String, _ value: String) -> some View { HStack(alignment: .top) { Text(name).font(.system(size: 11, weight: .medium)).frame(width: 145, alignment: .leading); Text(value).font(.system(size: 11)).foregroundColor(Palette.muted).textSelection(.enabled); Spacer() } }
}
