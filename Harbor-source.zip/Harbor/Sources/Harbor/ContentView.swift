import SwiftUI
import AppKit
import HarborCore

enum Palette {
    static let background = Color(red: 0.055, green: 0.068, blue: 0.081)
    static let sidebar = Color(red: 0.075, green: 0.091, blue: 0.105)
    static let card = Color(red: 0.091, green: 0.11, blue: 0.126)
    static let accent = Color(red: 0.38, green: 0.89, blue: 0.72)
    static let muted = Color(red: 0.55, green: 0.61, blue: 0.66)
}

struct ContentView: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        HStack(spacing: 0) {
            sidebar.frame(width: 228)
            Divider()
            VStack(spacing: 0) {
                HStack {
                    Label("LOCAL DEVELOPMENT", systemImage: "desktopcomputer").font(.system(size: 10, weight: .semibold, design: .monospaced)).foregroundColor(Palette.muted)
                    Spacer()
                    Circle().fill(model.activeCount > 0 ? Palette.accent : Palette.muted).frame(width: 6, height: 6)
                    Text("\(model.activeCount) active processes").font(.system(size: 11)).foregroundColor(Palette.muted)
                    Button { Task { await model.refresh() } } label: { Image(systemName: "arrow.clockwise") }.buttonStyle(.plain).padding(.leading, 12).disabled(model.refreshing).help("Refresh installed tools and services")
                }.padding(.horizontal, 32).frame(height: 54)
                Divider()
                ScrollView {
                    VStack(alignment: .leading, spacing: 26) {
                        if let project = model.currentProject { ProjectDetail(project: project) }
                        else {
                            switch model.selected {
                            case "projects": ProjectsPage()
                            case "services": ServicesPage()
                            case "activity": ActivityPage()
                            case "settings": SettingsPage()
                            default: OverviewPage()
                            }
                        }
                    }.padding(32).frame(maxWidth: 1250, alignment: .leading).frame(maxWidth: .infinity)
                }
            }.background(Palette.background)
        }.tint(Palette.accent)
        .sheet(isPresented: $model.showCreate) { CreateProjectSheet().environmentObject(model) }
        .alert("Harbor", isPresented: Binding(get: { model.error != nil }, set: { if !$0 { model.error = nil } })) { Button("OK") { model.error = nil } } message: { Text(model.error ?? "") }
        .task { await model.refresh() }
        .onReceive(Timer.publish(every: 20, on: .main, in: .common).autoconnect()) { _ in Task { await model.refresh() } }
    }
    var sidebar: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 11) {
                Image(systemName: "ferry.fill").font(.system(size: 24)).foregroundColor(Palette.accent)
                VStack(alignment: .leading, spacing: 2) { Text("harbor").font(.system(size: 25, weight: .bold, design: .rounded)); Text("A HOME FOR LARAVEL").font(.system(size: 8, weight: .bold, design: .monospaced)).tracking(1.8).foregroundColor(Palette.muted) }
            }.padding(.horizontal, 20).padding(.top, 38).padding(.bottom, 34)
            nav("overview", "Overview", "square.grid.2x2")
            nav("projects", "Projects", "folder", count: model.projects.count)
            nav("services", "Services", "server.rack")
            nav("activity", "Activity", "terminal", count: model.activeCount)
            Text("YOUR PROJECTS").font(.system(size: 9, weight: .semibold)).tracking(1.8).foregroundColor(Palette.muted).padding(.horizontal, 22).padding(.top, 28).padding(.bottom, 8)
            ScrollView {
                VStack(spacing: 3) {
                    if model.projects.isEmpty { Text("Your next idea starts here.").font(.system(size: 11)).foregroundColor(Palette.muted).padding(.horizontal, 20).padding(.vertical, 8) }
                    ForEach(model.projects) { project in nav(project.id.uuidString, project.name, "diamond") }
                }
            }
            Spacer(minLength: 12)
            nav("settings", "Settings & domains", "gearshape")
            VStack(alignment: .leading, spacing: 9) {
                Text("Created by darils").font(.system(size: 11, weight: .medium)).foregroundColor(Palette.accent)
                HStack { Circle().fill(Palette.accent).frame(width: 6, height: 6); Text("Native on macOS"); Spacer(); Text("0.1") }.font(.system(size: 10)).foregroundColor(Palette.muted)
            }.padding(22)
        }.background(Palette.sidebar)
    }
    func nav(_ id: String, _ name: String, _ icon: String, count: Int? = nil) -> some View {
        Button { model.selected = id } label: {
            HStack(spacing: 12) { Image(systemName: icon).frame(width: 18); Text(name).lineLimit(1); Spacer(); if let count { Text("\(count)").font(.system(size: 10, design: .monospaced)).foregroundColor(Palette.muted) } }
                .font(.system(size: 12, weight: model.selected == id ? .semibold : .regular))
                .foregroundColor(model.selected == id ? Palette.accent : Color.white.opacity(0.65))
                .padding(.horizontal, 13).padding(.vertical, 11)
                .background(model.selected == id ? Palette.accent.opacity(0.09) : .clear).cornerRadius(7)
        }.buttonStyle(.plain).padding(.horizontal, 10)
    }
}

struct PageHeading: View {
    let eyebrow: String; let title: String; let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(eyebrow.uppercased()).font(.system(size: 9, weight: .semibold, design: .monospaced)).tracking(2).foregroundColor(Palette.accent)
            Text(title).font(.system(size: 31, weight: .semibold))
            Text(subtitle).font(.system(size: 12)).foregroundColor(Palette.muted).fixedSize(horizontal: false, vertical: true)
        }
    }
}
struct Card<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View { content.padding(20).frame(maxWidth: .infinity, alignment: .leading).background(Palette.card).cornerRadius(12).overlay(RoundedRectangle(cornerRadius: 12).stroke(.white.opacity(0.055))) }
}
struct ActionButton: View {
    let title: String; let icon: String; var primary = false; let action: () -> Void
    var body: some View {
        Button(action: action) { Label(title, systemImage: icon).font(.system(size: 11, weight: .semibold)).padding(.horizontal, 14).padding(.vertical, 10).background(primary ? Palette.accent : .white.opacity(0.06)).foregroundColor(primary ? Palette.background : .white.opacity(0.85)).cornerRadius(6) }.buttonStyle(.plain)
    }
}
struct SectionTitle: View {
    let title: String; var detail = ""
    var body: some View { HStack { Text(title).font(.system(size: 16, weight: .semibold)); Spacer(); Text(detail).font(.system(size: 10)).foregroundColor(Palette.muted) } }
}
struct Badge: View {
    let text: String; var active = false
    var body: some View { HStack(spacing: 5) { Circle().fill(active ? Palette.accent : Palette.muted).frame(width: 5, height: 5); Text(text).font(.system(size: 10)) }.foregroundColor(active ? Palette.accent : Palette.muted).padding(.horizontal, 9).padding(.vertical, 5).background((active ? Palette.accent : Palette.muted).opacity(0.08)).cornerRadius(20) }
}

struct OverviewPage: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        HStack(alignment: .top) {
            PageHeading(eyebrow: "Your development harbor", title: "Good things start locally.", subtitle: "Your Laravel projects, services, and everyday tools. All in one place.")
            Spacer()
            ActionButton(title: "New project", icon: "plus", primary: true) { model.showCreate = true }.padding(.top, 24)
        }
        HStack(spacing: 14) {
            metric("Projects", "\(model.projects.count)", "folder")
            metric("Running processes", "\(model.activeCount)", "waveform.path")
            metric("Services online", "\(model.serviceStates.values.filter { $0 == "started" }.count)", "server.rack")
        }
        if model.executable("php") == nil || model.executable("composer") == nil {
            Card {
                HStack(spacing: 20) {
                    Image(systemName: "shippingbox.fill").font(.system(size: 30)).foregroundColor(Palette.accent)
                    VStack(alignment: .leading, spacing: 6) { Text("Let's get your Laravel stack ready.").font(.system(size: 16, weight: .semibold)); Text("Install PHP, Composer, Node.js, Redis, and Mailpit with Homebrew.\nNew Laravel projects use SQLite by default.").font(.system(size: 11)).foregroundColor(Palette.muted) }
                    Spacer()
                    ActionButton(title: model.brew == nil ? "Get Homebrew" : "Install essentials", icon: "arrow.down.circle", primary: true) { model.installStack() }.disabled(model.isBusy("brew-mutation"))
                }
            }
        }
        HStack { SectionTitle(title: "Your projects", detail: "LOCAL WORKSPACE"); ActionButton(title: "Import", icon: "folder.badge.plus") { model.importProject() } }
        if model.projects.isEmpty { EmptyProjects() }
        else {
            ForEach(model.projects.prefix(4)) { ProjectRow(project: $0) }
            HStack { ActionButton(title: "Start all web servers", icon: "play.fill", primary: true) { model.startWebProjects() }; ActionButton(title: "Stop project processes", icon: "stop.fill") { model.stopAll() }; Spacer() }
        }
        SectionTitle(title: "Your local stack", detail: model.refreshing ? "REFRESHING…" : "LIVE SYSTEM STATUS")
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            ForEach(ToolSpec.all.filter { ["mysql", "redis", "mailpit", "php"].contains($0.formula) }) { ToolCard(tool: $0) }
        }
    }
    func metric(_ title: String, _ value: String, _ icon: String) -> some View {
        Card { HStack { VStack(alignment: .leading, spacing: 14) { Text(title).font(.system(size: 11)).foregroundColor(Palette.muted); Text(value).font(.system(size: 30, weight: .medium, design: .rounded)) }; Spacer(); Image(systemName: icon).font(.system(size: 22)).foregroundColor(Palette.muted.opacity(0.6)) } }
    }
}

struct EmptyProjects: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        Card {
            VStack(spacing: 14) {
                Image(systemName: "folder.badge.plus").font(.system(size: 32, weight: .light)).foregroundColor(Palette.accent).padding(.top, 15)
                Text("Make room for your next idea.").font(.system(size: 17, weight: .medium))
                Text("Create a fresh Laravel application or bring an existing project.").font(.system(size: 12)).foregroundColor(Palette.muted)
                HStack { ActionButton(title: "Create Laravel project", icon: "plus", primary: true) { model.showCreate = true }; ActionButton(title: "Import folder", icon: "folder") { model.importProject() } }.padding(.bottom, 15)
            }.frame(maxWidth: .infinity)
        }
    }
}

struct ProjectsPage: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        HStack { PageHeading(eyebrow: "Workspace", title: "Projects", subtitle: "A dedicated runtime and process controls for every Laravel app."); Spacer(); ActionButton(title: "New project", icon: "plus", primary: true) { model.showCreate = true }; ActionButton(title: "Import", icon: "folder") { model.importProject() } }
        if model.projects.isEmpty { EmptyProjects() }
        else {
            TextField("Search projects", text: $model.search).textFieldStyle(.roundedBorder)
            ForEach(model.projects.filter { model.search.isEmpty || $0.name.localizedCaseInsensitiveContains(model.search) }) { ProjectRow(project: $0) }
        }
    }
}
struct ProjectRow: View {
    @EnvironmentObject var model: AppModel
    let project: Project
    var running: Bool { model.job(project, "web") != nil }
    var body: some View {
        Card {
            HStack(spacing: 17) {
                Image(systemName: "diamond.fill").font(.system(size: 20)).foregroundColor(.orange.opacity(0.9)).frame(width: 43, height: 43).background(.orange.opacity(0.08)).cornerRadius(10)
                Button { model.selected = project.id.uuidString } label: { VStack(alignment: .leading, spacing: 6) { Text(project.name).font(.system(size: 14, weight: .semibold)); Text("127.0.0.1:\(project.port)  ·  \(project.php)").font(.system(size: 10, design: .monospaced)).foregroundColor(Palette.muted) } }.buttonStyle(.plain)
                Spacer(); Badge(text: running ? "Process running" : "Stopped", active: running)
                Button { model.openURL(project.url.absoluteString) } label: { Image(systemName: "arrow.up.right.square") }.buttonStyle(.plain).help("Open local site").disabled(!running)
                ActionButton(title: running ? "Stop" : "Start", icon: running ? "stop.fill" : "play.fill", primary: !running) { model.toggle(project, "web") }
            }
        }
    }
}

struct ServicesPage: View {
    @EnvironmentObject var model: AppModel
    var body: some View {
        PageHeading(eyebrow: "Infrastructure", title: "Everything your app runs on.", subtitle: "Homebrew services are shared with other apps. Start runs a service without enabling launch at login; Stop affects all apps using it.")
        if model.brew == nil { Card { Text("Homebrew is required to install and manage services."); ActionButton(title: "Get Homebrew", icon: "arrow.up.right") { model.openURL("https://brew.sh") } } }
        if let error = model.serviceError { Text(error).font(.system(size: 11)).foregroundColor(.orange) }
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) { ForEach(ToolSpec.all) { ToolCard(tool: $0) } }
        SectionTitle(title: "PHP versions", detail: "SELECT A VERSION PER PROJECT")
        Card {
            VStack(alignment: .leading, spacing: 14) {
                Text(model.phpOptions.isEmpty ? "No PHP versions installed." : "Installed: " + model.phpOptions.map { "\($0) (\(model.installed[$0] ?? ""))" }.joined(separator: " · ")).font(.system(size: 12)).foregroundColor(Palette.muted)
                HStack { ForEach(["php@8.3", "php@8.4", "php@8.5"], id: \.self) { version in ActionButton(title: model.installed[version] == nil ? "Install \(version)" : "\(version) installed", icon: "shippingbox") { model.install(version) }.disabled(model.installed[version] != nil || model.isBusy("brew-mutation")) } }
                Text("Each project's selected PHP is used for Artisan, Composer, and its terminal. Installed versions depend on Homebrew availability.").font(.system(size: 11)).foregroundColor(Palette.muted)
            }
        }
    }
}
struct ToolCard: View {
    @EnvironmentObject var model: AppModel
    let tool: ToolSpec
    var version: String? { model.installed[tool.formula] }
    var running: Bool { model.serviceStates[tool.formula] == "started" }
    var body: some View {
        Card {
            VStack(alignment: .leading, spacing: 18) {
                HStack(spacing: 12) {
                    Image(systemName: tool.icon).font(.system(size: 21)).foregroundColor(Palette.accent).frame(width: 30)
                    VStack(alignment: .leading, spacing: 5) { Text(tool.name).font(.system(size: 14, weight: .semibold)); Text(tool.detail).font(.system(size: 10)).foregroundColor(Palette.muted) }
                    Spacer()
                }
                HStack {
                    Badge(text: !model.ready ? "Checking" : version == nil ? "Not installed" : tool.service ? (model.serviceStates[tool.formula] ?? "Unknown") : "Installed", active: tool.service ? running : version != nil)
                    Spacer()
                    if let version { Text(version).font(.system(size: 10, design: .monospaced)).foregroundColor(Palette.muted).lineLimit(1) }
                }
                HStack {
                    if version == nil { ActionButton(title: "Install", icon: "arrow.down.circle") { model.install(tool.formula) }.disabled(!model.ready || model.isBusy("brew-mutation")) }
                    else if tool.service {
                        ActionButton(title: running ? "Stop" : "Start", icon: running ? "stop.fill" : "play.fill") { model.service(tool.formula, action: running ? "stop" : "run") }.disabled(model.isBusy("brew-mutation") || model.serviceError != nil)
                        if tool.formula == "mailpit" { ActionButton(title: "Inbox", icon: "envelope.open") { model.openURL("http://127.0.0.1:8025") }.disabled(!running) }
                    } else { Text("Ready for your projects").font(.system(size: 10)).foregroundColor(Palette.muted) }
                    Spacer()
                    if !tool.port.isEmpty { Text(":" + tool.port).font(.system(size: 10, design: .monospaced)).foregroundColor(Palette.muted) }
                }.frame(height: 33)
            }
        }
    }
}
