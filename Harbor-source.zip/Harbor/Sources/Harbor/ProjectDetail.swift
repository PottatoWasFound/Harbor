import SwiftUI
import AppKit
import HarborCore

struct ProjectDetail: View {
    @EnvironmentObject var model: AppModel
    let project: Project
    @State private var command = "about"
    @State private var portText = ""
    @State private var confirmCommand = false
    @State private var pendingArguments: [String] = []
    var body: some View {
        VStack(alignment: .leading, spacing: 26) {
        HStack(alignment: .top) {
            PageHeading(eyebrow: "Laravel application", title: project.name, subtitle: project.path)
            Spacer()
            ActionButton(title: "Open site", icon: "arrow.up.right", primary: true) { model.openURL(project.url.absoluteString) }.padding(.top, 24)
        }
        HStack {
            ActionButton(title: "Terminal", icon: "terminal") { model.terminal(project) }
            ActionButton(title: "Finder", icon: "folder") { model.reveal(project.path) }
            ActionButton(title: "Edit .env", icon: "slider.horizontal.3") { model.edit(project.path + "/.env") }
            ActionButton(title: "Laravel log", icon: "doc.text") { model.edit(project.path + "/storage/logs/laravel.log") }
            Spacer()
            Menu("More") {
                Button("Install Composer dependencies") { model.dependencies(project, node: false) }
                Button("Install npm dependencies") { model.dependencies(project, node: true) }
                Divider()
                Button("Link .test domain in Terminal") { model.valet(project, action: "link") }
                Button("Secure with HTTPS in Terminal") { model.valet(project, action: "secure") }
                Button("Open Valet HTTPS site") { model.openURL("https://\(project.name).test") }
                Divider()
                Button("Remove from Harbor (keep files)") { model.remove(project) }
            }.fixedSize()
        }
        SectionTitle(title: "Project processes", detail: "MANAGED BY HARBOR · STOPPED ON QUIT")
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
            process("web", "Web server", "Laravel development server · :\(project.port)", "globe")
            process("vite", "Vite", "Frontend & hot reload · :\(project.port + 1000)", "bolt")
            process("queue", "Queue worker", "Default queue · 3 attempts", "square.stack.3d.up")
            process("scheduler", "Scheduler", "Run scheduled Laravel tasks", "clock")
            process("horizon", "Horizon", "Requires laravel/horizon + Redis", "chart.bar.xaxis")
            process("reverb", "Reverb", "Requires laravel/reverb · :\(project.port + 2000)", "antenna.radiowaves.left.and.right")
        }
        Card {
            HStack(spacing: 18) {
                VStack(alignment: .leading, spacing: 5) { Text("Runtime").font(.system(size: 13, weight: .semibold)); Text("Stop project processes before changing these.").font(.system(size: 10)).foregroundColor(Palette.muted) }
                Spacer()
                Picker("PHP", selection: Binding(get: { project.php }, set: { model.update(project, php: $0) })) {
                    ForEach(Array(Set(model.phpOptions + [project.php])).sorted(), id: \.self) { Text($0).tag($0) }
                }.frame(width: 160)
                TextField("Port", text: $portText).textFieldStyle(.roundedBorder).frame(width: 72)
                ActionButton(title: "Save port", icon: "checkmark") {
                    if let port = Int(portText) { model.update(project, port: port) } else { model.error = "Enter a numeric port." }
                }
            }
        }.onAppear { portText = String(project.port) }.onChange(of: project.id) { _ in portText = String(project.port) }
        SectionTitle(title: "Artisan workbench", detail: "USES THIS PROJECT'S PHP")
        Card {
            VStack(alignment: .leading, spacing: 17) {
                HStack {
                    Text("php artisan").font(.system(size: 12, design: .monospaced)).foregroundColor(Palette.accent)
                    TextField("Command and arguments", text: $command).textFieldStyle(.roundedBorder).font(.system(size: 12, design: .monospaced)).onSubmit { prepareCommand() }
                    ActionButton(title: "Run", icon: "play.fill", primary: true) { prepareCommand() }.disabled(model.isBusy("\(project.id):artisan"))
                }
                HStack {
                    quick("Routes", "route:list")
                    quick("Clear caches", "optimize:clear")
                    quick("Migrations", "migrate:status")
                    quick("Run tests", "test")
                    quick("About", "about")
                    ActionButton(title: "Tinker", icon: "terminal") { model.terminal(project, command: "php artisan tinker") }
                }
                Text("Any Artisan command is supported. Commands that change application or database state ask for confirmation. Use Terminal for interactive commands.").font(.system(size: 10)).foregroundColor(Palette.muted)
            }
        }
        Card {
            VStack(alignment: .leading, spacing: 10) {
                Text("Connect your local services").font(.system(size: 13, weight: .semibold))
                Text("Set your project's .env to match its services. Harbor does not replace your existing configuration.").font(.system(size: 11)).foregroundColor(Palette.muted)
                Text("MySQL  127.0.0.1:3306     Redis  127.0.0.1:6379\nMailpit SMTP  127.0.0.1:1025     Inbox  127.0.0.1:8025").font(.system(size: 11, design: .monospaced)).foregroundColor(Palette.accent).textSelection(.enabled)
                Text("Database credentials come from your local installation. Reverb uses port \(project.port + 2000); set REVERB_PORT and VITE_REVERB_PORT accordingly. Horizon and Reverb must be installed and configured in the project first.").font(.system(size: 10)).foregroundColor(Palette.muted)
            }
        }
        if !model.jobs.filter({ $0.projectID == project.id }).isEmpty {
            SectionTitle(title: "Recent activity")
            ForEach(model.jobs.filter { $0.projectID == project.id }.prefix(4)) { JobCard(job: $0) }
        }
        }
        // Custom commands can target production through .env, so show the exact command before execution.
        .alert("Run this Artisan command?", isPresented: $confirmCommand) {
            Button("Cancel", role: .cancel) {}
            Button("Run command") { model.artisan(project, pendingArguments) }
        } message: { Text("php artisan " + pendingArguments.map(Shell.quote).joined(separator: " ") + "\n\nThis uses the database and services configured in this project's .env, including any remote connections.") }
    }
    func prepareCommand() {
        do {
            let args = try Shell.arguments(command)
            guard !args.isEmpty else { return }
            let readOnly = ["about", "list", "help", "route:list", "migrate:status", "schedule:list"]
            if args.count == 1 && readOnly.contains(args[0]) { model.artisan(project, args) }
            else { pendingArguments = args; confirmCommand = true }
        } catch { model.error = error.localizedDescription }
    }
    func quick(_ title: String, _ value: String) -> some View {
        ActionButton(title: title, icon: "chevron.right") { command = value; prepareCommand() }
    }
    func process(_ kind: String, _ title: String, _ detail: String, _ icon: String) -> some View {
        let job = model.job(project, kind)
        return Card {
            VStack(alignment: .leading, spacing: 13) {
                HStack { Image(systemName: icon).foregroundColor(Palette.accent); Spacer(); Badge(text: job == nil ? "Stopped" : "Process running", active: job != nil) }
                Text(title).font(.system(size: 14, weight: .semibold))
                Text(detail).font(.system(size: 10)).foregroundColor(Palette.muted).frame(height: 28, alignment: .topLeading)
                ActionButton(title: job == nil ? "Start" : "Stop", icon: job == nil ? "play.fill" : "stop.fill") { model.toggle(project, kind) }
            }
        }
    }
}

struct CreateProjectSheet: View {
    @EnvironmentObject var model: AppModel
    @Environment(\.dismiss) var dismiss
    @State private var name = ""
    @State private var parent = NSHomeDirectory() + "/Documents"
    var body: some View {
        VStack(alignment: .leading, spacing: 23) {
            PageHeading(eyebrow: "A fresh start", title: "New Laravel project", subtitle: "Create the latest stable Laravel app with Composer.")
            VStack(alignment: .leading, spacing: 8) { Text("PROJECT NAME").font(.system(size: 9, weight: .semibold)).foregroundColor(Palette.muted); TextField("my-next-idea", text: $name).textFieldStyle(.roundedBorder) }
            VStack(alignment: .leading, spacing: 8) {
                Text("PARENT FOLDER").font(.system(size: 9, weight: .semibold)).foregroundColor(Palette.muted)
                HStack { Text(parent).font(.system(size: 11)).lineLimit(1).truncationMode(.middle); Spacer(); Button("Choose…") { let panel = NSOpenPanel(); panel.canChooseDirectories = true; panel.canChooseFiles = false; if panel.runModal() == .OK, let url = panel.url { parent = url.path } } }
            }
            Text("Composer downloads Laravel and runs its setup scripts. After creation, install npm dependencies from the project menu, then start Vite. Starter kits and authentication can be added through Laravel's installer in Terminal.").font(.system(size: 11)).foregroundColor(Palette.muted)
            HStack { Button("Cancel") { dismiss() }.keyboardShortcut(.cancelAction); Spacer(); ActionButton(title: "Create project", icon: "plus", primary: true) { model.createProject(name: name, parent: parent) }.disabled(!ProjectRules.validName(name)) }
        }.padding(32).frame(width: 480).background(Palette.background)
    }
}
