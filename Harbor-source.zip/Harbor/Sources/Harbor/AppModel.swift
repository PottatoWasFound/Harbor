import AppKit
import SwiftUI
import HarborCore

struct ToolSpec: Identifiable {
    var id: String { formula }
    let name: String
    let formula: String
    let detail: String
    let icon: String
    let service: Bool
    let port: String
    static let all: [ToolSpec] = [
        .init(name: "PHP", formula: "php", detail: "Laravel runtime", icon: "chevron.left.forwardslash.chevron.right", service: false, port: ""),
        .init(name: "Composer", formula: "composer", detail: "PHP dependencies", icon: "shippingbox", service: false, port: ""),
        .init(name: "Node.js", formula: "node", detail: "Vite & frontend tools", icon: "hexagon", service: false, port: ""),
        .init(name: "MySQL", formula: "mysql", detail: "Relational database", icon: "cylinder.split.1x2", service: true, port: "3306"),
        .init(name: "PostgreSQL", formula: "postgresql@17", detail: "Alternative database", icon: "externaldrive", service: true, port: "5432"),
        .init(name: "Redis", formula: "redis", detail: "Cache, queues & sessions", icon: "square.3.layers.3d", service: true, port: "6379"),
        .init(name: "Mailpit", formula: "mailpit", detail: "Local email inbox", icon: "envelope", service: true, port: "8025 / 1025"),
        .init(name: "Nginx", formula: "nginx", detail: "Optional web server · Valet manages its own configuration", icon: "network", service: true, port: "8080")
    ]
}

@MainActor final class AppModel: ObservableObject {
    @Published var projects: [Project] = []
    @Published var selected = "overview"
    @Published var jobs: [Job] = []
    @Published var installed: [String: String] = [:]
    @Published var serviceStates: [String: String] = [:]
    @Published var refreshing = false
    @Published var error: String?
    @Published var showCreate = false
    @Published var search = ""
    @Published var ready = false
    @Published var serviceError: String?
    private var storeWritable = true
    let support: URL
    let store: ProjectStore
    let brew: String?
    var environment: [String: String] {
        var env = ProcessInfo.processInfo.environment
        env["PATH"] = "/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/usr/local/sbin:\(NSHomeDirectory())/Library/Application Support/Herd/bin:\(NSHomeDirectory())/.composer/vendor/bin:\(NSHomeDirectory())/.config/composer/vendor/bin:/usr/bin:/bin:/usr/sbin:/sbin"
        env["HOMEBREW_NO_AUTO_UPDATE"] = "1"; env["HOMEBREW_NO_ENV_HINTS"] = "1"
        env["NO_COLOR"] = "1"; env["TERM"] = "dumb"
        return env
    }
    var phpOptions: [String] { installed.keys.filter { $0 == "php" || $0.hasPrefix("php@") }.sorted() }
    var activeCount: Int { jobs.filter(\.running).count }
    var currentProject: Project? { projects.first { $0.id.uuidString == selected } }

    init() {
        support = ProcessInfo.processInfo.environment["HARBOR_DATA_DIR"].map { URL(fileURLWithPath: $0) } ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Harbor")
        store = ProjectStore(file: support.appendingPathComponent("projects.json"))
        brew = ["/opt/homebrew/bin/brew", "/usr/local/bin/brew"].first { FileManager.default.isExecutableFile(atPath: $0) }
        do { projects = try store.load() } catch { self.error = "Could not load projects: \(error.localizedDescription) The original file is preserved. Fix it and reopen Harbor."; storeWritable = false }
    }

    func executable(_ name: String, php: String = "php") -> String? {
        if name == "php", let brew {
            let prefix = URL(fileURLWithPath: brew).deletingLastPathComponent().deletingLastPathComponent().path
            let candidate = "\(prefix)/opt/\(php)/bin/php"
            if FileManager.default.isExecutableFile(atPath: candidate) { return candidate }
            if php != "php" { return nil }
        }
        return (environment["PATH"] ?? "").split(separator: ":").map { "\($0)/\(name)" }.first { FileManager.default.isExecutableFile(atPath: $0) }
    }

    func projectEnvironment(_ project: Project?) -> [String: String] {
        var env = environment
        if let project, let php = executable("php", php: project.php) {
            env["PATH"] = URL(fileURLWithPath: php).deletingLastPathComponent().path + ":" + (env["PATH"] ?? "")
        }
        return env
    }

    func refresh() async {
        guard !refreshing else { return }; refreshing = true
        defer { refreshing = false; ready = true }
        guard let brew else { await detectExternalTools(); return }
        async let formulae = Command.capture(brew, ["list", "--formula", "--versions"], environment: environment)
        async let services = Command.capture(brew, ["services", "list", "--json"], environment: environment)
        let (f, s) = await (formulae, services)
        if f.code == 0 {
            installed = Dictionary(f.output.split(separator: "\n").compactMap { line -> (String, String)? in
                let parts = line.split(separator: " "); guard parts.count > 1 else { return nil }
                return (String(parts[0]), parts.dropFirst().joined(separator: ", "))
            }, uniquingKeysWith: { first, _ in first })
        } else { error = "Could not inspect Homebrew: \(f.output)" }
        if s.code == 0, let data = s.output.data(using: .utf8), let states = try? JSONDecoder().decode([BrewService].self, from: data) {
            serviceStates = Dictionary(states.map { ($0.name, $0.status) }, uniquingKeysWith: { first, _ in first }); serviceError = nil
        } else { serviceError = "Service status unavailable. \(s.output.prefix(300))"; serviceStates = [:] }
        await detectExternalTools()
    }

    private func detectExternalTools() async {
        for name in ["php", "composer", "node"] where installed[name] == nil {
            guard let path = executable(name) else { continue }
            let result = await Command.capture(path, name == "php" ? ["-r", "echo PHP_VERSION;"] : ["--version"], environment: environment)
            if result.code == 0 { installed[name] = String(String(result.output.split(separator: "\n").first ?? "Detected").prefix(45)) + " · external" }
        }
    }

    @discardableResult func run(key: String, title: String, executable: String, arguments: [String], project: Project? = nil, directory: String? = nil, completion: ((Int32) -> Void)? = nil) -> Job? {
        guard !jobs.contains(where: { $0.key == key && $0.running }) else { return nil }
        let job = Job(key: key, title: title, projectID: project?.id, logs: support.appendingPathComponent("Logs"))
        jobs.insert(job, at: 0)
        do {
            try job.start(executable: executable, arguments: arguments, directory: directory ?? project?.path, environment: projectEnvironment(project)) { [weak self] code in
                self?.objectWillChange.send(); completion?(code)
            }
            objectWillChange.send()
        } catch { job.exitCode = -1; job.append(error.localizedDescription); self.error = error.localizedDescription }
        return job
    }

    func job(_ project: Project, _ kind: String) -> Job? { jobs.first { $0.key == "\(project.id):\(kind)" && $0.running } }
    func isBusy(_ key: String) -> Bool { jobs.contains { $0.key == key && $0.running } }
    func toggle(_ project: Project, _ kind: String) {
        if let job = job(project, kind) { job.stop(); objectWillChange.send(); return }
        if kind == "vite" {
            guard FileManager.default.fileExists(atPath: project.path + "/package.json") else { error = "This project has no package.json."; return }
            guard let npm = executable("npm") else { error = "Install Node.js in Services first."; return }
            run(key: "\(project.id):vite", title: "\(project.name) · Vite", executable: npm, arguments: ["run", "dev", "--", "--host", "127.0.0.1", "--port", String(project.port + 1000), "--strictPort"], project: project)
            return
        }
        guard FileManager.default.fileExists(atPath: project.path + "/vendor/autoload.php") else { error = "Install Composer dependencies for this project first."; return }
        let args: [String]
        switch kind {
        case "web": args = ["serve", "--host=127.0.0.1", "--port=\(project.port)", "--tries=1"]
        case "queue": args = ["queue:work", "--tries=3", "--timeout=90"]
        case "scheduler": args = ["schedule:work"]
        case "horizon": args = ["horizon"]
        case "reverb": args = ["reverb:start", "--host=127.0.0.1", "--port=\(project.port + 2000)"]
        default: return
        }
        artisan(project, args, key: kind, title: kind.capitalized)
    }

    func artisan(_ project: Project, _ arguments: [String], key: String = "artisan", title: String = "Artisan") {
        guard let php = executable("php", php: project.php) else { error = "Install PHP in Services first."; return }
        run(key: "\(project.id):\(key)", title: "\(project.name) · \(title)", executable: php, arguments: ["artisan"] + arguments, project: project)
    }

    func dependencies(_ project: Project, node: Bool) {
        if !node && executable("php", php: project.php) == nil { error = "The selected PHP runtime is unavailable. Install it or choose another version."; return }
        let command = node ? "npm" : "composer"
        guard let exe = executable(command) else { error = "Install \(command) in Services first."; return }
        run(key: "\(project.id):dependencies", title: "\(project.name) · \(command) install", executable: exe, arguments: node ? ["install"] : ["install", "--no-interaction"], project: project)
        selected = "activity"
    }

    func install(_ formula: String) {
        guard let brew else { openURL("https://brew.sh"); return }
        run(key: "brew-mutation", title: "Install \(formula)", executable: brew, arguments: ["install", formula]) { [weak self] _ in Task { await self?.refresh() } }
        selected = "activity"
    }
    func installStack() {
        guard let brew else { openURL("https://brew.sh"); return }
        let missing = ["php", "composer", "node", "redis", "mailpit"].filter { installed[$0] == nil }
        guard !missing.isEmpty else { selected = "services"; return }
        run(key: "brew-mutation", title: "Install Laravel essentials", executable: brew, arguments: ["install"] + missing) { [weak self] _ in Task { await self?.refresh() } }
        selected = "activity"
    }
    func service(_ formula: String, action: String) {
        guard let brew else { return }
        run(key: "brew-mutation", title: "\(action.capitalized) \(formula)", executable: brew, arguments: ["services", action, formula]) { [weak self] _ in Task { await self?.refresh() } }
    }

    func persist(_ changed: [Project]) {
        guard storeWritable else { error = "Fix the saved project list and restart Harbor before making changes."; return }
        do { try store.save(changed); projects = changed } catch { self.error = "Could not save projects: \(error.localizedDescription)" }
    }
    func importProject() {
        let panel = NSOpenPanel(); panel.canChooseDirectories = true; panel.canChooseFiles = false
        panel.prompt = "Import Laravel project"
        if panel.runModal() == .OK, let url = panel.url { addProject(url.path) }
    }
    func addProject(_ path: String) {
        let path = ProjectRules.canonical(path)
        guard ProjectRules.isLaravel(path) else { error = "Choose a Laravel root folder containing artisan and composer.json."; return }
        if let existing = projects.first(where: { ProjectRules.canonical($0.path) == path }) { selected = existing.id.uuidString; return }
        do {
            let project = Project(name: URL(fileURLWithPath: path).lastPathComponent, path: path, port: try ProjectRules.nextPort(projects), php: phpOptions.first ?? "php")
            persist(projects + [project]); selected = project.id.uuidString
        } catch { self.error = error.localizedDescription }
    }
    func createProject(name: String, parent: String) {
        guard ProjectRules.validName(name) else { error = "Use a lowercase name starting with a letter, followed by letters, numbers or hyphens (up to 48 characters)."; return }
        guard let composer = executable("composer"), executable("php") != nil else { error = "Install PHP and Composer from Services first."; return }
        let path = URL(fileURLWithPath: parent).appendingPathComponent(name).path
        guard !FileManager.default.fileExists(atPath: path) else { error = "That folder already exists. Choose another name or import it."; return }
        run(key: "create:\(path)", title: "Create \(name)", executable: composer, arguments: ["create-project", "laravel/laravel", path, "--prefer-dist", "--no-interaction"], directory: parent) { [weak self] code in
            if code == 0 { self?.addProject(path) }
        }
        showCreate = false; selected = "activity"
    }
    func update(_ project: Project, php: String? = nil, port: Int? = nil) {
        guard !jobs.contains(where: { $0.projectID == project.id && $0.running }) else { error = "Stop this project's processes before changing PHP or its port."; return }
        if let port, !ProjectRules.portAvailable(port, projects: projects.filter { $0.id != project.id }) {
            error = "Choose a port between 1024 and 63535 that does not overlap another project's web, Vite (+1000), or Reverb (+2000) port."; return
        }
        persist(projects.map { p in var copy = p; if p.id == project.id { if let php { copy.php = php }; if let port { copy.port = port } }; return copy })
    }
    func remove(_ project: Project) {
        guard !jobs.contains(where: { $0.projectID == project.id && $0.running }) else { error = "Stop this project's processes before removing it."; return }
        persist(projects.filter { $0.id != project.id }); selected = "projects"
    }
    func stopAll(includeTools: Bool = false) { jobs.filter { $0.running && (includeTools || $0.projectID != nil) }.forEach { $0.stop() }; objectWillChange.send() }
    func startWebProjects() { for project in projects where job(project, "web") == nil { toggle(project, "web") } }
    func openURL(_ url: String) { if let url = URL(string: url) { NSWorkspace.shared.open(url) } }
    func reveal(_ path: String) { NSWorkspace.shared.selectFile(nil, inFileViewerRootedAtPath: path) }
    func edit(_ path: String) {
        guard FileManager.default.fileExists(atPath: path) else { error = "This file does not exist yet: \(path)"; return }
        NSWorkspace.shared.open(URL(fileURLWithPath: path))
    }
    func terminal(_ project: Project? = nil, command: String? = nil) {
        let content = "#!/bin/zsh\nexport PATH=" + Shell.quote(projectEnvironment(project)["PATH"] ?? "") + "\n" + (project.map { "cd " + Shell.quote($0.path) + " || exit 1\n" } ?? "") + (command.map { $0 + "\n" } ?? "") + "exec /bin/zsh -i\n"
        let path = support.appendingPathComponent("Terminal/\(UUID().uuidString).command")
        do {
            try FileManager.default.createDirectory(at: path.deletingLastPathComponent(), withIntermediateDirectories: true)
            try content.write(to: path, atomically: true, encoding: .utf8)
            try FileManager.default.setAttributes([.posixPermissions: 0o700], ofItemAtPath: path.path)
            NSWorkspace.shared.open(path)
        } catch { self.error = error.localizedDescription }
    }
    func valet(_ project: Project?, action: String) {
        if action == "install" {
            terminal(command: "composer global require laravel/valet && valet install")
        } else if let project {
            guard executable("valet") != nil else { error = "Set up Laravel Valet from Settings first."; return }
            guard ProjectRules.validName(project.name) else { error = "Valet links need a lowercase project name containing letters, numbers and hyphens. Use Terminal to choose a custom alias."; return }
            terminal(project, command: "valet \(action) " + Shell.quote(project.name))
        }
    }
}
