import Foundation
import Darwin

@MainActor final class Job: ObservableObject, Identifiable {
    let id = UUID()
    let key: String
    let title: String
    let projectID: UUID?
    let started = Date()
    let process = Process()
    @Published var output = ""
    @Published var running = false
    @Published var stopping = false
    @Published var exitCode: Int32?
    private var pipe: Pipe?
    private var logHandle: FileHandle?
    let logURL: URL

    init(key: String, title: String, projectID: UUID?, logs: URL) {
        self.key = key; self.title = title; self.projectID = projectID
        self.logURL = logs.appendingPathComponent("\(id.uuidString).log")
    }

    func start(executable: String, arguments: [String], directory: String?, environment: [String: String], onExit: @escaping (Int32) -> Void) throws {
        let bundleWorker = Bundle.main.bundleURL.appendingPathComponent("Contents/MacOS/harbor-worker").path
        let siblingWorker = URL(fileURLWithPath: CommandLine.arguments[0]).deletingLastPathComponent().appendingPathComponent("harbor-worker").path
        let worker = FileManager.default.isExecutableFile(atPath: bundleWorker) ? bundleWorker : siblingWorker
        guard FileManager.default.isExecutableFile(atPath: worker) else { throw NSError(domain: "Harbor", code: 1, userInfo: [NSLocalizedDescriptionKey: "The process helper is missing. Rebuild Harbor with scripts/build.sh."]) }
        try FileManager.default.createDirectory(at: logURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        FileManager.default.createFile(atPath: logURL.path, contents: nil, attributes: [.posixPermissions: 0o600])
        logHandle = try FileHandle(forWritingTo: logURL)
        process.executableURL = URL(fileURLWithPath: worker)
        process.arguments = [executable] + arguments
        process.environment = environment
        if let directory { process.currentDirectoryURL = URL(fileURLWithPath: directory) }
        let pipe = Pipe(); self.pipe = pipe
        process.standardOutput = pipe; process.standardError = pipe
        process.standardInput = FileHandle.nullDevice
        append("$ " + ([executable] + arguments).map { $0.contains(" ") ? "\"\($0)\"" : $0 }.joined(separator: " ") + "\n")
        process.terminationHandler = { [weak self] process in
            DispatchQueue.main.async {
                guard let self else { return }
                self.running = false; self.stopping = false; self.exitCode = process.terminationStatus
                // Clean up workers left behind by a command that has exited.
                kill(-process.processIdentifier, SIGTERM)
                onExit(process.terminationStatus)
            }
        }
        do { try process.run(); running = true }
        catch { try? logHandle?.close(); throw error }
        // One reader preserves byte order and drains the pipe before closing the log.
        DispatchQueue.global(qos: .utility).async { [weak self] in
            while true {
                let data = pipe.fileHandleForReading.availableData
                if data.isEmpty { break }
                let chunk = String(decoding: data, as: UTF8.self)
                DispatchQueue.main.async { self?.append(chunk) }
            }
            DispatchQueue.main.async { try? self?.logHandle?.close(); self?.logHandle = nil }
        }
    }

    func append(_ text: String) {
        output += text
        if output.count > 120_000 { output = String(output.suffix(100_000)) }
        if let data = text.data(using: .utf8) { try? logHandle?.write(contentsOf: data) }
    }

    func stop() {
        guard running && !stopping else { return }
        stopping = true
        let pid = process.processIdentifier
        if getpgid(pid) == pid { kill(-pid, SIGTERM) } else { process.terminate() }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
            // The session is owned by this job, so descendants are included.
            if kill(-pid, 0) == 0 { kill(-pid, SIGKILL) }
            if let self, self.process.isRunning { self.process.terminate() }
        }
    }
}

struct CommandResult { let code: Int32; let output: String }

enum Command {
    static func capture(_ executable: String, _ arguments: [String], environment: [String: String]) async -> CommandResult {
        await withCheckedContinuation { continuation in
            DispatchQueue.global(qos: .utility).async {
                let process = Process(), pipe = Pipe()
                process.executableURL = URL(fileURLWithPath: executable); process.arguments = arguments
                process.environment = environment; process.standardOutput = pipe; process.standardError = pipe
                process.standardInput = FileHandle.nullDevice
                do {
                    try process.run()
                    DispatchQueue.global().asyncAfter(deadline: .now() + 30) { if process.isRunning { process.terminate() } }
                    let data = pipe.fileHandleForReading.readDataToEndOfFile()
                    process.waitUntilExit()
                    continuation.resume(returning: CommandResult(code: process.terminationStatus, output: String(decoding: data, as: UTF8.self)))
                } catch { continuation.resume(returning: CommandResult(code: -1, output: error.localizedDescription)) }
            }
        }
    }
}
