#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

// A private process group lets Harbor stop a command and its descendants together.
int main(int argc, char **argv) {
    if (argc < 2) return 64;
    if (setpgid(0, 0) == -1 && getpgrp() != getpid()) { perror("setpgid"); return 71; }
    execvp(argv[1], argv + 1);
    perror("execvp");
    return 127;
}
