import Foundation

public struct Project: Identifiable, Codable, Equatable {
    public var id: UUID
    public var name: String
    public var path: String
    public var port: Int
    public var php: String
    public init(id: UUID = UUID(), name: String, path: String, port: Int, php: String = "php") {
        self.id = id; self.name = name; self.path = path; self.port = port; self.php = php
    }
    public var url: URL { URL(string: "http://127.0.0.1:\(port)")! }
}

public enum ProjectRules {
    public static func validName(_ name: String) -> Bool {
        name.range(of: "\\A[a-z][a-z0-9-]{0,47}\\z", options: .regularExpression) != nil
    }
    public static func nextPort(_ projects: [Project]) throws -> Int {
        guard let port = (8000...8999).first(where: { portAvailable($0, projects: projects) }) else {
            throw HarborError.message("No project ports are available between 8000 and 8999.")
        }
        return port
    }
    public static func portAvailable(_ port: Int, projects: [Project]) -> Bool {
        guard (1024...63535).contains(port) else { return false }
        let requested = Set([port, port + 1000, port + 2000])
        return projects.allSatisfy { requested.isDisjoint(with: [$0.port, $0.port + 1000, $0.port + 2000]) }
    }
    public static func isLaravel(_ path: String) -> Bool {
        let root = URL(fileURLWithPath: path)
        return FileManager.default.fileExists(atPath: root.appendingPathComponent("artisan").path)
            && FileManager.default.fileExists(atPath: root.appendingPathComponent("composer.json").path)
    }
    public static func canonical(_ path: String) -> String {
        URL(fileURLWithPath: path).resolvingSymlinksInPath().standardizedFileURL.path
    }
}

public enum HarborError: LocalizedError {
    case message(String)
    public var errorDescription: String? { if case .message(let message) = self { return message }; return nil }
}

public enum Shell {
    public static func quote(_ value: String) -> String { "'" + value.replacingOccurrences(of: "'", with: "'\\''") + "'" }
    // This parser only tokenizes arguments. It never expands variables or executes shell syntax.
    public static func arguments(_ input: String) throws -> [String] {
        var result: [String] = [], token = "", quoted: Character?, escaped = false, started = false
        for c in input {
            if escaped { token.append(c); escaped = false; started = true; continue }
            if c == "\\" && quoted != "'" { escaped = true; started = true; continue }
            if let q = quoted {
                if c == q { quoted = nil } else { token.append(c) }
                started = true
            } else if c == "\"" || c == "'" { quoted = c; started = true }
            else if c.isWhitespace { if started { result.append(token); token = ""; started = false } }
            else { token.append(c); started = true }
        }
        guard quoted == nil && !escaped else { throw HarborError.message("Finish the quote or escaped character in your command.") }
        if started { result.append(token) }
        return result
    }
}

public struct ProjectStore {
    public let file: URL
    public init(file: URL) { self.file = file }
    public func load() throws -> [Project] {
        guard FileManager.default.fileExists(atPath: file.path) else { return [] }
        let projects = try JSONDecoder().decode([Project].self, from: Data(contentsOf: file))
        guard Set(projects.map(\.id)).count == projects.count,
              Set(projects.map(\.port)).count == projects.count,
              projects.allSatisfy({ p in ProjectRules.portAvailable(p.port, projects: projects.filter { $0.id != p.id }) }) else {
            throw HarborError.message("The saved project list contains invalid or duplicate ports or IDs.")
        }
        return projects
    }
    public func save(_ projects: [Project]) throws {
        try FileManager.default.createDirectory(at: file.deletingLastPathComponent(), withIntermediateDirectories: true)
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(projects).write(to: file, options: .atomic)
    }
}

public struct BrewService: Decodable {
    public let name: String
    public let status: String
    public let exit_code: Int?
}
