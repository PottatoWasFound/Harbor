import Foundation
import Darwin
import HarborCore

final class HarborCoreTests {
    func testCommandArgumentsPreserveQuotedValuesAndShellSyntax() throws {
        expectEqual(try Shell.arguments("make:model 'Order Item' --flag=\"two words\""), ["make:model", "Order Item", "--flag=two words"])
        expectEqual(try Shell.arguments("test $(touch /tmp/example) ; echo $HOME"), ["test", "$(touch", "/tmp/example)", ";", "echo", "$HOME"])
        expectEqual(try Shell.arguments("command '' escaped\\ space"), ["command", "", "escaped space"])
        expectThrows(try Shell.arguments("command 'unfinished"))
        expectThrows(try Shell.arguments("command \\"))
    }
    func testShellQuoteRoundTripsSpecialPaths() throws {
        let original = "folder's name; $(whoami) `date`\nsecond line"
        let process = Process(), pipe = Pipe()
        process.executableURL = URL(fileURLWithPath: "/bin/sh")
        process.arguments = ["-c", "printf %s " + Shell.quote(original)]
        process.standardOutput = pipe
        try process.run()
        let result = String(decoding: pipe.fileHandleForReading.readDataToEndOfFile(), as: UTF8.self)
        process.waitUntilExit()
        expectEqual(result, original)
    }
    func testProjectNamesRejectPathsAndCommandSyntax() {
        for name in ["my-app", "app2", "a"] { expectTrue(ProjectRules.validName(name)) }
        for name in ["", "../project", "foo/bar", "app; rm", "two words", "--flag", "UPPER", "x\n", String(repeating: "x", count: 49)] { expectFalse(ProjectRules.validName(name), name) }
    }
    func testPortsSkipExistingAndReportExhaustion() throws {
        let projects = [Project(name: "one", path: "/one", port: 8000), Project(name: "three", path: "/three", port: 8002)]
        expectEqual(try ProjectRules.nextPort(projects), 8001)
        expectFalse(ProjectRules.portAvailable(9000, projects: projects))
        expectFalse(ProjectRules.portAvailable(6000, projects: projects))
        expectFalse(ProjectRules.portAvailable(64000, projects: []))
        expectThrows(try ProjectRules.nextPort((8000...8999).map { Project(name: "app", path: "/app", port: $0) }))
    }
    func testAtomicPersistenceAndCorruptionIsNotOverwritten() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = ProjectStore(file: directory.appendingPathComponent("projects.json"))
        expectEqual(try store.load(), [])
        let project = Project(name: "store", path: "/folder with spaces/store", port: 8000, php: "php@8.4")
        try store.save([project]); expectEqual(try store.load(), [project])
        let invalid = Data("not json".utf8); try invalid.write(to: store.file)
        expectThrows(try store.load())
        expectEqual(try Data(contentsOf: store.file), invalid)
    }
    func testDuplicatePortsAreRejectedOnLoad() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let store = ProjectStore(file: directory.appendingPathComponent("projects.json"))
        try store.save([Project(name: "a", path: "/a", port: 8000), Project(name: "b", path: "/b", port: 8000)])
        expectThrows(try store.load())
    }
    func testLaravelDetectionRequiresBothFiles() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: directory) }
        expectFalse(ProjectRules.isLaravel(directory.path))
        try Data().write(to: directory.appendingPathComponent("artisan"))
        expectFalse(ProjectRules.isLaravel(directory.path))
        try Data("{}".utf8).write(to: directory.appendingPathComponent("composer.json"))
        expectTrue(ProjectRules.isLaravel(directory.path))
    }
}

func expectEqual<T: Equatable>(_ a: @autoclosure () throws -> T, _ b: @autoclosure () throws -> T) {
    do { guard try a() == b() else { fatalError("Values differ") } } catch { fatalError("Unexpected error: \(error)") }
}
func expectTrue(_ value: Bool) { precondition(value, "Expected true") }
func expectFalse(_ value: Bool, _ message: String = "") { precondition(!value, message) }
func expectThrows<T>(_ value: @autoclosure () throws -> T) {
    do { _ = try value() } catch { return }; fatalError("Expected an error")
}

@main struct Checks {
    static func main() throws {
        let tests = HarborCoreTests()
        try tests.testCommandArgumentsPreserveQuotedValuesAndShellSyntax()
        try tests.testShellQuoteRoundTripsSpecialPaths()
        tests.testProjectNamesRejectPathsAndCommandSyntax()
        try tests.testPortsSkipExistingAndReportExhaustion()
        try tests.testAtomicPersistenceAndCorruptionIsNotOverwritten()
        try tests.testDuplicatePortsAreRejectedOnLoad()
        try tests.testLaravelDetectionRequiresBothFiles()
        print("PASS: 7 core checks (arguments, injection resistance, names, ports, persistence, corruption, detection)")
        let worker = URL(fileURLWithPath: CommandLine.arguments[0]).deletingLastPathComponent().appendingPathComponent("harbor-worker")
        let process = Process(), pipe = Pipe()
        process.executableURL = worker
        process.arguments = ["/bin/sh", "-c", "sleep 60 & echo $!; wait"]
        process.standardOutput = pipe
        try process.run()
        let line = pipe.fileHandleForReading.availableData
        guard let child = Int32(String(decoding: line, as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)) else { fatalError("Worker did not start") }
        expectEqual(getpgid(process.processIdentifier), process.processIdentifier)
        expectEqual(getpgid(child), process.processIdentifier)
        kill(-process.processIdentifier, SIGTERM)
        process.waitUntilExit()
        usleep(200_000)
        expectEqual(kill(child, 0), -1)
        print("PASS: process-group launch and child-process cleanup")
        let bad = Process()
        bad.executableURL = worker; bad.arguments = ["/harbor/nonexistent-executable"]
        bad.standardError = FileHandle.nullDevice
        try bad.run(); bad.waitUntilExit()
        expectEqual(bad.terminationStatus, 127)
        print("PASS: missing executable reports failure")
    }
}
